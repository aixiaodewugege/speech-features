function display(CPD)

disp('gmux_CPD object');
disp(struct(CPD));
