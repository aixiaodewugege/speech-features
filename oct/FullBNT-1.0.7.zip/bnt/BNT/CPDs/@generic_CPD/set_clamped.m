function CPD = set_clamped(CPD, bit)

CPD.clamped = bit;
